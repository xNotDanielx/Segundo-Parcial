﻿namespace Presentacion
{
    partial class Portada
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnVerinfoDeclaracion = new System.Windows.Forms.Button();
            this.btnVeremplazamiento = new System.Windows.Forms.Button();
            this.btnVertotal = new System.Windows.Forms.Button();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(190, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Renta";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(88, 125);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(280, 46);
            this.btnRegistrar.TabIndex = 1;
            this.btnRegistrar.Text = "Registrar el formulario de declaración";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnVerinfoDeclaracion
            // 
            this.btnVerinfoDeclaracion.Location = new System.Drawing.Point(88, 177);
            this.btnVerinfoDeclaracion.Name = "btnVerinfoDeclaracion";
            this.btnVerinfoDeclaracion.Size = new System.Drawing.Size(280, 46);
            this.btnVerinfoDeclaracion.TabIndex = 2;
            this.btnVerinfoDeclaracion.Text = "Visualizar la información";
            this.btnVerinfoDeclaracion.UseVisualStyleBackColor = true;
            this.btnVerinfoDeclaracion.Click += new System.EventHandler(this.btnVerinfoDeclaracion_Click);
            // 
            // btnVeremplazamiento
            // 
            this.btnVeremplazamiento.Location = new System.Drawing.Point(88, 229);
            this.btnVeremplazamiento.Name = "btnVeremplazamiento";
            this.btnVeremplazamiento.Size = new System.Drawing.Size(280, 46);
            this.btnVeremplazamiento.TabIndex = 3;
            this.btnVeremplazamiento.Text = "Visualizar las declaraciones con emplazamiento y sin emplazamiento";
            this.btnVeremplazamiento.UseVisualStyleBackColor = true;
            this.btnVeremplazamiento.Click += new System.EventHandler(this.btnVeremplazamiento_Click);
            // 
            // btnVertotal
            // 
            this.btnVertotal.Location = new System.Drawing.Point(88, 281);
            this.btnVertotal.Name = "btnVertotal";
            this.btnVertotal.Size = new System.Drawing.Size(280, 46);
            this.btnVertotal.TabIndex = 4;
            this.btnVertotal.Text = "Visualizar el total declarado por con emplazamiento y sin emplazamiento.";
            this.btnVertotal.UseVisualStyleBackColor = true;
            this.btnVertotal.Click += new System.EventHandler(this.btnVertotal_Click);
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(88, 333);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(280, 46);
            this.btnGenerar.TabIndex = 5;
            this.btnGenerar.Text = "Generar un archivo plano con el total declarado con emplazamiento y sin emplazami" +
    "ento.";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // Portada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 430);
            this.Controls.Add(this.btnGenerar);
            this.Controls.Add(this.btnVertotal);
            this.Controls.Add(this.btnVeremplazamiento);
            this.Controls.Add(this.btnVerinfoDeclaracion);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.label1);
            this.Name = "Portada";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button btnVerinfoDeclaracion;
        private System.Windows.Forms.Button btnVeremplazamiento;
        private System.Windows.Forms.Button btnVertotal;
        private System.Windows.Forms.Button btnGenerar;
    }
}

