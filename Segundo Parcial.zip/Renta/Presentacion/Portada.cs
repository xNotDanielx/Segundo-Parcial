﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Portada : Form
    {
        public Portada()
        {
            InitializeComponent();
        }
        

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Registrar formr = new Registrar();
            abrir_form(formr);
        }

        public void abrir_form(Form f)
        {
            this.Hide();
            f.ShowDialog(this);
        }

        private void btnVerinfoDeclaracion_Click(object sender, EventArgs e)
        {
            VerInfo formr = new VerInfo();
            abrir_form(formr);
        }

        private void btnVeremplazamiento_Click(object sender, EventArgs e)
        {
            DeclaracionesxEmplazamiento formr = new DeclaracionesxEmplazamiento();
            abrir_form(formr);
        }

        private void btnVertotal_Click(object sender, EventArgs e)
        {
            DeclaradoxEmplazamiento formr = new DeclaradoxEmplazamiento();
            abrir_form(formr);
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            GenerarArchivo formr = new GenerarArchivo();
            abrir_form(formr);
        }
    }
}
