﻿using Datos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class Servicio_Renta
    {

        double SMLDV = 1160000 / 30;
        Archivo archivo = new Archivo();
        List<Persona> personas;
        public Servicio_Renta()
        {
            Refresh();
        }

        void Refresh()
        {
            try
            {
                personas = archivo.consultar();

            }
             catch (Exception)
            {

            }
        }
        public void Add(Persona persona)
        {
            try
            {
                if (persona == null) { return; }
                archivo.Guardar_Persona(persona);
            }
            catch (Exception)
            {
                return;
            }

        }
        double Sancion = 0;
        public double Renta(double Valor,int Cantidad_Dias,bool Emplazamiento)
        {
            if (Emplazamiento == true)
            {
                Sancion = (Valor * Cantidad_Dias) * 0.03;              
            }
            else
            {
                Sancion = (Valor * Cantidad_Dias) * (4*SMLDV);
            }
            return Sancion;
        }

        public List<Persona> GetAll()
        {
            Refresh();
            if (personas.Count == 0) return null;

            return personas;
        }

        public void DeleteContact(string contactoEliminar)
        {
            try
            {
                foreach (var item in personas)
                {
                    if (contactoEliminar == item.Nombre)
                    {
                        personas.Remove(item);
                        archivo.ActualizarLista(personas);
                    }
                }
            }
            catch (Exception)
            {

            }
        }

        public void Update(string contactoActualizar, Persona contacto)
        {
            try
            {
                foreach (var item in personas)
                {
                    if (contactoActualizar == item.Nombre)
                    {
                        item.Nombre_Formulario = contacto.Nombre_Formulario;
                        item.ID = contacto.ID;
                        item.Nombre = contacto.Nombre;
                        item.Fecha_Realizacion = contacto.Fecha_Realizacion;
                        item.Emplazamiento = contacto.Emplazamiento;
                        item.Valor_Declarado = contacto.Valor_Declarado;
                        archivo.ActualizarLista(personas);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
