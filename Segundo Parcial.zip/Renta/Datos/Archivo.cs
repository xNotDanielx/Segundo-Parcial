﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Archivo
    {
        public string ruta = "Renta.txt";
        public String Guardar_Persona(Persona persona)
        {
            StreamWriter sw = new StreamWriter(ruta, true);
            sw.WriteLine(persona.ToString());
            sw.Close();
            return "se guardo Correctamente... ";
        }

        public Persona Mapeador(String linea)
        {
            var persona = new Persona();
            string[] aux = linea.Split(';');
            persona.Tipo = aux[0];
            persona.Nombre_Formulario = aux[1];
            persona.ID = aux[2];
            persona.Nombre = aux[3];
            persona.Fecha_Realizacion = DateTime.Parse(aux[4]);
            persona.Emplazamiento = bool.Parse(aux[5]);
            persona.Valor_Declarado = float.Parse(aux[6]);
            return persona;
        }

        public void ActualizarLista(List<Persona> persons)
        {
            string rutatemp = "Temporal.txt";
            try
            {
                StreamWriter sw = new StreamWriter(rutatemp, true);
                foreach (var item in persons)
                {
                    sw.WriteLine(item.ToString());
                }
                sw.Close();
                File.Delete(ruta);
                File.Move(rutatemp, ruta);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Persona> consultar()
        {
            var lista = new List<Persona>();
            try
            {
                var sr = new StreamReader(ruta);
                //var linea = string.Empty;
                while (!sr.EndOfStream)
                {
                    //  linea = sr.ReadLine();
                    lista.Add(Mapeador(sr.ReadLine()));
                }
                sr.Close();
                return lista;
            }
            catch (Exception)
            {

                return null;
            }
        }

    }
}

