﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Persona
    {
        public Persona() {}
        public string Tipo { get; set; }
        public string Nombre_Formulario { get; set; }
        public string ID { get; set; }
        public string Nombre { get; set; }
        public DateTime Fecha_Realizacion { get; set; }
        public bool Emplazamiento { get; set; }
        public double Valor_Declarado { get; set; }

        public Persona(string tipo, string nombre_Formulario, string iD, string nombre, DateTime fecha_Realizacion, bool emplazamiento, double valor_Declarado)
        {
            Tipo = tipo;
            Nombre_Formulario = nombre_Formulario;
            ID = iD;
            Nombre = nombre;
            Fecha_Realizacion = fecha_Realizacion;
            Emplazamiento = emplazamiento;
            Valor_Declarado = valor_Declarado;
        }

        public override string ToString()
        {
            return $"{Tipo};{Nombre_Formulario};{ID};{Nombre};{Fecha_Realizacion};{Emplazamiento};{Valor_Declarado}";
        }
    }
}
